<article class="masonry__brick entry format-link animate-this">
                        
                        <div class="entry__thumb">
                            <div class="link-wrap">
                            <h2><?php the_excerpt() ?></h2>
                                <cite>
                                    <a target="_blank" href="https://www.dreamhost.com/r.cgi?287326">https://www.dreamhost.com</a>
                                </cite>
                            </div>
                        </div>
                        
</article> <!-- end article -->
