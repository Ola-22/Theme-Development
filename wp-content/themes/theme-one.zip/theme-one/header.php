<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
    <!--- basic page needs
    ================================================== -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head() ?>

    <!-- CSS
    ================================================== -->
    <link rel="stylesheet" href="/wordpress2/wp-content/themes/theme-one/assets/css/base.css">
    <link rel="stylesheet" href="/wordpress2/wp-content/themes/theme-one/assets/css/vendor.css">
    <link rel="stylesheet" href="/wordpress2/wp-content/themes/theme-one/assets/css/main.css">

    <!-- script
    ================================================== -->
    <script src="/wordpress2/wp-content/themes/theme-one/js/modernizr.js"></script>
</head>

<body>

    <!-- preloader
    ================================================== -->
    <div id="preloader">
        <div id="loader" class="dots-fade">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>

    <div id="top" class="s-wrap site-wrapper">

        <!-- site header
        ================================================== -->
        <header class="s-header">

            <div class="header__top">
                <div class="header__logo">
                    <?php //the_custom_logo() ?>
                    <a class="site-logo" href="index.php">
                        <img src="/wordpress2/wp-content/themes/theme-one/images/logo.svg" alt="Homepage">
                    </a>
                </div>

                <div class="header__search">
                <?= get_search_form() ?>        
                </div>  <!-- end header__search -->

            </div> <!-- end header__top -->
            <nav class="header__nav-wrap">
            <?php wp_nav_menu([
                'menu' => 'nav',
                'menu_class' => 'header__nav-wrap',
                'container' => 'ul',
                'container_class' => 'header__nav',
                'theme_location' => 'primary',
                //'container' => '',
                //'menu_class' => 'header__nav',
                'items_wrap' => '<ul class="header__nav">%3$s</ul>',
                'before' => '',
                'after' => '',

            ]);
            ?>
            <?php get_template_part('inc/widget') ?>
            </nav>
        </header> <!-- end s-header -->
