<article class="masonry__brick entry format-quote animate-this">
                            
            <div class="entry__thumb">
                <blockquote>
                        <?php the_excerpt() ?>
        
                                    <cite><?php the_author() ?></cite>
                                </blockquote>
                            </div>   
            
</article> <!-- end article -->