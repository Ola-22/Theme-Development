<?php get_header() ?>
<div class="s-content">
<h1>Page Not Found</h1>
</div>
<?php get_footer() ?>
