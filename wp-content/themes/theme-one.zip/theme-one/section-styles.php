
<section id="styles" class="column large-full">
        <div class="row section-intro add-bottom">

            <div class="column large-full">

                <h1 class="display-1"><?php the_title() ?></h1>

                    <p class="lead">
                        <?php the_content() ?>
                    </p>
                            

            </div>
        </div>
</section> <!-- end styles -->