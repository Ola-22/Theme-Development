
<section class="column large-full entry format-standard">

                    <div class="media-wrap">
                        <div>
                        <?php the_post_thumbnail('mytheme-thumbnail') ?>                           </div>
                    </div>

                    <div class="content__page-header">
                        <h1 class="display-1">
                        <?php the_title() ?>
                        </h1>
                    </div> <!-- end content__page-header -->

                    <p class="lead drop-cap">
                    <?php the_content() ?>
                    </p>

                    <div class="row">
                        <div class="column large-six tab-full">
                            <h4></h4>
    
                            <p>
                            </p>
    
                        </div>
    
                        <div class="column large-six tab-full">
                            <h4></h4>
    
                            <p>
                            </p>
    
                        </div>
                    </div>

                    <h3 class="h2"></h3>
        
                </section>