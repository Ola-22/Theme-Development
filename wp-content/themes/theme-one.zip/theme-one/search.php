<?php get_header() ?>

        <div class="s-content">
            <p style="margin-left:25px !important; font-size:25px; font-weight:bold">search Result: "<?= esc_html(get_search_query()) ?> "</p>
            <div class="masonry-wrap">
            <div class="masonry">
                    <div class="grid-sizer"></div>
                    <?php 
                    $post_loop = new WP_Query([
                    'order' => 'ASC',
                    'post_type' => 'post',
                    ]);
                    if ($post_loop->have_posts()) :
                        while ($post_loop->have_posts()) :
                            $post_loop->the_post(); ?>
                            <?php get_template_part('content', get_post_format()); ?>
                    <?php 
                    endwhile;
                    
                endif;
                        wp_reset_postdata();
                    ?>
                </div> <!-- end masonry -->
            </div> <!-- end masonry-wrap -->
        </div> <!-- end s-content -->
<?php get_footer() ?>