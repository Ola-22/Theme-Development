        <!-- footer
        ================================================== -->
        <footer class="s-footer">
            <div class="row">
                <div class="column large-full footer__content">
                    <div class="footer__copyright">
                        <span>© Copyright Typerite 2019</span> 
                        <span>Design by <a href="https://www.styleshout.com/">StyleShout</a></span>
                    </div>
                </div>
            </div>

            <div class="go-top">
                <a class="smoothscroll" title="Back to Top" href="#top"></a>
            </div>
            <?php wp_footer() ?>
        </footer>

    </div> <!-- end s-wrap -->


    <!-- Java Script
    ================================================== -->
    <script src="/wordpress2/wp-content/themes/theme-one/js/jquery-3.2.1.min.js"></script>
    <script src="/wordpress2/wp-content/themes/theme-one/js/plugins.js"></script>
    <script src="/wordpress2/wp-content/themes/theme-one/js/main.js"></script>

</body>