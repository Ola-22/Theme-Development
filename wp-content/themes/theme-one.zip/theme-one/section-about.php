<section class="column large-full entry format-standard">

                    <div class="media-wrap">
                        <div class="image">
                           <?php the_post_thumbnail('mytheme-thumbnail') ?>
                        </div>
                    </div>

                    <div class="content__page-header">
                    <h1 class="display-1">
    <?php the_content() ?>
    </h1>
 
                </section>
